# Centro Actoral – Gobernación de Boyacá (Fase 1)
Requisitos: Node.js 18+ y Docker Desktop.

1. `docker compose up -d`   (levanta PostgreSQL y crea las tablas desde db/init.sql)
2. `npm install`
3. `npm start`  → abre http://localhost:3000

**Administrador:** se crea automáticamente al iniciar el servidor con los datos de `.env`
(admin@boyaca.gov.co / Admin2026*). No existe registro de administradores. Cambia la clave en `.env` antes de publicar.
Para reiniciar la BD desde cero: `docker compose down -v`.

## Fase 2 incluida
Convocatorias con postulación, cursos, noticias, panel admin (resumen, perfiles, cursos, convocatorias, noticias, historial).
**Si ya levantaste la BD antes**, recréala para que cargue las tablas nuevas: `docker compose down -v` y luego `docker compose up -d`.

## Actualización (mockups completos)
- Registro de 5 pasos (revisión final, áreas/especialidades como chips, reel, portafolio y redes).
- Filtros en la vitrina: género, experiencia, estatura, edad, ciudad, habilidad.
- Panel del actor (/cuenta.html): mis clases, progreso, trayectoria, logros y aplicaciones.
- Admin: editar cursos/convocatorias/noticias, ver inscritos y marcar progreso, gráfica de actividad por día.
- Archivos: por defecto en `uploads/`. Para usar Cloudinary llena CLOUDINARY_* en `.env` (cuenta gratuita en cloudinary.com).
- IMPORTANTE: la BD cambió. Ejecuta `docker compose down -v` y luego `docker compose up -d` antes de `npm start`.

## Si ya tienes la BD creada y falla "es_proceso_formacion" al crear cursos
`docker compose exec db psql -U postgres -d centro_actoral -c "ALTER TABLE cursos_y_talleres ALTER COLUMN es_proceso_formacion SET DEFAULT false;"`

## Versión 3
- Nuevo Home (/) con información del Centro, perfiles sugeridos, noticias, convocatorias y cursos.
- El catálogo de actores ahora está en /actores.html con filtros rediseñados.
- Botón "Salir" en el menú y "Cerrar sesión" en el panel de administrador.
- Letras, botones y tarjetas más grandes. No cambia la base de datos: solo reemplaza la carpeta y reinicia `npm start`.
