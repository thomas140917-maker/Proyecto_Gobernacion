const $=s=>document.querySelector(s),api=async(u,o={})=>{const t=localStorage.token;const r=await fetch(u,{...o,headers:{...(o.body&&!(o.body instanceof FormData)?{'Content-Type':'application/json'}:{}),...(t?{Authorization:'Bearer '+t}:{}),...o.headers}});const d=await r.json();if(!r.ok)throw Error(d.error||'Error');return d};
const icon=i=>`<span class="material-icons">${i}</span>`;
function nav(on){const rol=localStorage.rol;$('#nav').innerHTML=`<b onclick="location='/'" style="cursor:pointer">${icon('theater_comedy')} Centro <span>Actoral</span> Boyacá</b>
 <a href="/" class="${on=='h'?'on':''}">${icon('home')} Inicio</a><a href="/actores.html" class="${on=='v'?'on':''}">${icon('groups')} Actores</a><a href="/convocatorias.html" class="${on=='c'?'on':''}">${icon('campaign')} Convocatorias</a><a href="/novedades.html" class="${on=='n'?'on':''}">${icon('newspaper')} Novedades</a><a href="/registro.html" class="${on=='r'?'on':''}">${icon('how_to_reg')} Regístrate</a>
 ${rol=='admin'?`<a href="/admin.html" class="${on=='a'?'on':''}">${icon('admin_panel_settings')} Panel</a>`:''}
 <a href="${rol=='actor'?'/cuenta.html':'/login.html'}" class="${on=='l'?'on':''}">${icon(rol?'account_circle':'login')} ${rol?'Mi cuenta':'Ingresar'}</a>${rol?`<a href="#" onclick="localStorage.clear();location='/';return false">${icon('logout')} Salir</a>`:''}`}
// RNF-09: compresión de imagen en el navegador antes de subir
function comprimir(file,max=1200){return new Promise(res=>{const i=new Image();i.onload=()=>{const k=Math.min(1,max/Math.max(i.width,i.height)),c=document.createElement('canvas');c.width=i.width*k;c.height=i.height*k;c.getContext('2d').drawImage(i,0,0,c.width,c.height);c.toBlob(b=>res(new File([b],'foto.jpg',{type:'image/jpeg'})),'image/jpeg',.8)};i.src=URL.createObjectURL(file)})}

const fecha=d=>d?new Date(d).toLocaleDateString('es-CO',{day:'numeric',month:'short',year:'numeric'}):'';
