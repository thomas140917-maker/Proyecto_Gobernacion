// Rutas Fase 2: cursos, convocatorias, noticias, postulaciones, resumen e historial
const T={cursos:{t:'cursos_y_talleres',pk:'curso_id',o:'creado_en',c:['titulo','descripcion','instructor','fecha_inicio_inscripcion','fecha_inicio_curso','cupo_maximo']},
 convocatorias:{t:'convocatorias',pk:'convocatoria_id',o:'creado_en',c:['titulo','descripcion','requisitos','ubicacion','modalidad','cupo_maximo','fecha_cierre']},
 noticias:{t:'noticias',pk:'noticia_id',o:'publicado_en',c:['titulo','resumen_para_carta','resumen_para_galeria','imagen_url']}};
module.exports=(app,db,auth,wrap)=>{
 app.get('/api/pub/:k',wrap(async(q,r)=>{const x=T[q.params.k];if(!x)return r.sendStatus(404);
  r.json((await db.query(`SELECT * FROM ${x.t} ${x.t=='convocatorias'?"WHERE estado='APROBADO'":''} ORDER BY ${x.o} DESC`)).rows)}));
 app.post('/api/admin/:k',auth('admin'),wrap(async(q,r)=>{const x=T[q.params.k];if(!x)return r.sendStatus(404);
  const b={...q.body},cols=x.c.filter(c=>b[c]!==undefined&&b[c]!=='');
  if(x.t=='convocatorias')b.estado='APROBADO',cols.push('estado');if(x.t=='cursos')b.es_proceso_formacion=false,cols.push('es_proceso_formacion');
  const {rows:[n]}=await db.query(`INSERT INTO ${x.t}(creado_por_admin_id,${cols}) VALUES($1,${cols.map((_,i)=>'$'+(i+2))}) RETURNING ${x.pk} id`,[q.u.id,...cols.map(c=>b[c])]);
  await db.query("INSERT INTO historial_auditoria(tipo_accion,entidad_afectada,entidad_id,realizado_por_admin_id,observacion_accion) VALUES('CREAR',$1,$2,$3,$4)",[x.t,n.id,q.u.id,'Creó: '+b.titulo]);r.json(n)}));
 app.delete('/api/admin/:k/:id',auth('admin'),wrap(async(q,r)=>{const x=T[q.params.k];if(!x)return r.sendStatus(404);
  await db.query(`DELETE FROM ${x.t} WHERE ${x.pk}=$1`,[q.params.id]);
  await db.query("INSERT INTO historial_auditoria(tipo_accion,entidad_afectada,entidad_id,realizado_por_admin_id,observacion_accion) VALUES('ELIMINAR',$1,$2,$3,'Eliminado')",[x.t,q.params.id,q.u.id]);r.json({ok:true})}));
 app.post('/api/convocatorias/:id/aplicar',auth('actor'),wrap(async(q,r)=>{
  await db.query("INSERT INTO postulaciones_castings(convocatoria_id,actor_id,estado) VALUES($1,$2,'PENDIENTE') ON CONFLICT DO NOTHING",[q.params.id,q.u.id]);r.json({ok:true})}));
 app.get('/api/mis-postulaciones',auth('actor'),wrap(async(q,r)=>r.json((await db.query('SELECT c.titulo,c.modalidad,c.fecha_cierre,p.estado,p.postulado_en FROM postulaciones_castings p JOIN convocatorias c USING(convocatoria_id) WHERE p.actor_id=$1 ORDER BY postulado_en DESC',[q.u.id])).rows)));
 app.get('/api/admin/resumen',auth('admin'),wrap(async(q,r)=>{const n=async s=>+(await db.query(s)).rows[0].n;
  r.json({pendientes:await n("SELECT count(*) n FROM perfiles_actores WHERE estado='PENDIENTE'"),aprobados:await n("SELECT count(*) n FROM perfiles_actores WHERE estado='APROBADO'"),
   cursos:await n('SELECT count(*) n FROM cursos_y_talleres'),convocatorias:await n("SELECT count(*) n FROM convocatorias WHERE estado='APROBADO'"),
   postulaciones:await n('SELECT count(*) n FROM postulaciones_castings'),acciones:await n("SELECT count(*) n FROM historial_auditoria WHERE creado_en>now()-interval '30 days'"),
   admin:await n("SELECT count(*) n FROM historial_auditoria WHERE realizado_por_admin_id IS NOT NULL AND creado_en>now()-interval '30 days'")})}));
 app.get('/api/admin/historial',auth('admin'),wrap(async(q,r)=>r.json((await db.query(`SELECT h.tipo_accion,h.entidad_afectada,h.observacion_accion,h.creado_en,
  CASE WHEN h.realizado_por_admin_id IS NOT NULL THEN 'Administrador' ELSE 'Usuario' END rol,COALESCE(a.nombre,ac.nombre_completo) quien
  FROM historial_auditoria h LEFT JOIN administradores a ON a.admin_id=h.realizado_por_admin_id LEFT JOIN actores ac ON ac.actor_id=h.realizado_por_actor_id ORDER BY h.creado_en DESC LIMIT 60`)).rows)));

 const aud=(t,e,id,u,o)=>db.query('INSERT INTO historial_auditoria(tipo_accion,entidad_afectada,entidad_id,realizado_por_admin_id,observacion_accion) VALUES($1,$2,$3,$4,$5)',[t,e,id,u,o]);
 app.put('/api/admin/inscripciones/:a/:c',auth('admin'),wrap(async(q,r)=>{const {progreso,estado}=q.body;
  await db.query('UPDATE inscripciones_cursos SET progreso=COALESCE($3,progreso),estado=COALESCE($4,estado) WHERE actor_id=$1 AND curso_id=$2',[q.params.a,q.params.c,progreso,estado]);r.json({ok:true})}));
 app.put('/api/admin/:k/:id',auth('admin'),wrap(async(q,r)=>{const x=T[q.params.k];if(!x)return r.sendStatus(404);
  const cols=x.c.filter(c=>q.body[c]!==undefined&&q.body[c]!=='');
  await db.query(`UPDATE ${x.t} SET ${cols.map((c,i)=>c+'=$'+(i+2))} WHERE ${x.pk}=$1`,[q.params.id,...cols.map(c=>q.body[c])]);
  await aud('ACTUALIZAR',x.t,q.params.id,q.u.id,'Editó: '+(q.body.titulo||''));r.json({ok:true})}));
 app.post('/api/cursos/:id/inscribir',auth('actor'),wrap(async(q,r)=>{
  await db.query('INSERT INTO inscripciones_cursos(actor_id,curso_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[q.u.id,q.params.id]);r.json({ok:true})}));
 app.get('/api/admin/actividad',auth('admin'),wrap(async(q,r)=>r.json((await db.query(`SELECT to_char(d,'DD/MM') dia,count(h.log_id) FILTER(WHERE h.realizado_por_admin_id IS NULL)::int usuarios,count(h.log_id) FILTER(WHERE h.realizado_por_admin_id IS NOT NULL)::int admin
  FROM generate_series(current_date-13,current_date,'1 day') d LEFT JOIN historial_auditoria h ON h.creado_en::date=d::date GROUP BY d ORDER BY d`)).rows)));
 app.get('/api/mi-panel',auth('actor'),wrap(async(q,r)=>{const id=q.u.id,g=async(s)=>(await db.query(s,[id])).rows;
  r.json({perfil:(await g('SELECT a.nombre_completo nombre,p.foto_perfil_url foto,p.estado,p.motivo_rechazo,p.nivel_experiencia nivel FROM actores a JOIN perfiles_actores p USING(actor_id) WHERE actor_id=$1'))[0],
   clases:await g('SELECT c.titulo,i.progreso,i.estado,c.fecha_inicio_curso FROM inscripciones_cursos i JOIN cursos_y_talleres c USING(curso_id) WHERE i.actor_id=$1 ORDER BY c.fecha_inicio_curso'),
   postulaciones:await g('SELECT c.titulo,c.modalidad,c.fecha_cierre,p.estado FROM postulaciones_castings p JOIN convocatorias c USING(convocatoria_id) WHERE p.actor_id=$1 ORDER BY postulado_en DESC')})}));

 app.get('/api/admin/cursos/:id/inscritos',auth('admin'),wrap(async(q,r)=>r.json((await db.query('SELECT a.actor_id,a.nombre_completo,i.progreso,i.estado FROM inscripciones_cursos i JOIN actores a USING(actor_id) WHERE i.curso_id=$1',[q.params.id])).rows)));
};
