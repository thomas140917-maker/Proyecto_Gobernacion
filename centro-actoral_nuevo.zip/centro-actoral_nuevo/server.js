require('dotenv').config();
const express=require('express'),{Pool}=require('pg'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken'),multer=require('multer'),path=require('path'),fs=require('fs');
const app=express(),db=new Pool({connectionString:process.env.DATABASE_URL}),S=process.env.JWT_SECRET;
const up=multer({dest:path.join(__dirname,'uploads'),limits:{fileSize:60*1024*1024}});
app.use(express.json());app.use('/uploads',express.static('uploads'));app.use(express.static('public'));
const wrap=f=>(q,r)=>f(q,r).catch(e=>{console.error(e);r.status(500).json({error:e.detail||e.message})});
const auth=rol=>(q,r,n)=>{try{const t=jwt.verify((q.headers.authorization||'').slice(7),S);if(rol&&t.rol!==rol)throw 0;q.u=t;n()}catch{r.status(401).json({error:'No autorizado'})}};
const cl=process.env;
const url=async f=>{if(!f)return null;if(cl.CLOUDINARY_CLOUD_NAME){const ts=Math.floor(Date.now()/1000),fd=new FormData();
 fd.append('file',new Blob([fs.readFileSync(f.path)]),f.originalname);fd.append('api_key',cl.CLOUDINARY_API_KEY);fd.append('timestamp',ts);
 fd.append('signature',require('crypto').createHash('sha1').update('timestamp='+ts+cl.CLOUDINARY_API_SECRET).digest('hex'));
 const r=await(await fetch('https://api.cloudinary.com/v1_1/'+cl.CLOUDINARY_CLOUD_NAME+'/auto/upload',{method:'POST',body:fd})).json();fs.unlinkSync(f.path);
 if(!r.secure_url)throw Error('Cloudinary: '+(r.error&&r.error.message));return r.secure_url}return '/uploads/'+f.filename};

// Administrador "quemado": se crea automáticamente al iniciar si no existe (datos en .env)
async function seedAdmin(){
  const {rowCount}=await db.query('SELECT 1 FROM administradores WHERE correo=$1',[process.env.ADMIN_CORREO]);
  if(!rowCount){await db.query('INSERT INTO administradores(correo,contrasena_hash,nombre,apellido,esta_activo) VALUES($1,$2,$3,$4,true)',
    [process.env.ADMIN_CORREO,await bcrypt.hash(process.env.ADMIN_PASSWORD,10),'Administrador','Gobernación']);console.log('Admin creado:',process.env.ADMIN_CORREO)}
}

// RF-01 Registro público (sin autenticación)
app.post('/api/registro',up.fields([{name:'foto',maxCount:1},{name:'video',maxCount:1},{name:'autorizacion',maxCount:1}]),wrap(async(q,r)=>{
  const b=q.body,f=q.files||{},c=await db.connect();
  try{
    if(b.acepta_terminos!=='true')return r.status(400).json({error:'Debe aceptar el tratamiento de datos (Ley 1581)'});
    await c.query('BEGIN');
    const {rows:[a]}=await c.query(`INSERT INTO actores(correo,contrasena_hash,nombre_completo,tipo_documento,numero_documento,fecha_nacimiento,municipio,ciudad,telefono,acepta_terminos,esta_activo,genero,estatura_cm)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,true,true,$10,$11) RETURNING actor_id`,[b.correo,await bcrypt.hash(b.contrasena,10),b.nombre_completo,b.tipo_documento,b.numero_documento,b.fecha_nacimiento,b.municipio,b.ciudad||b.municipio,b.telefono,b.genero||null,b.estatura||null]);
    await c.query('INSERT INTO perfiles_actores(actor_id,nombre_artistico,tiene_experiencia,biografia,foto_perfil_url,estado,nivel_experiencia,reel_url,portafolio_url) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)',
      [a.actor_id,b.nombre_artistico||null,b.tiene_experiencia==='true',b.biografia,await url(f.foto?.[0]),'PENDIENTE',b.nivel||null,b.reel_url||null,b.portafolio_url||null]);
    for(const h of JSON.parse(b.habilidades||'[]')){
      const {rows:[x]}=await c.query('INSERT INTO habilidades(nombre) VALUES($1) ON CONFLICT(nombre) DO UPDATE SET nombre=EXCLUDED.nombre RETURNING habilidad_id',[h]);
      await c.query('INSERT INTO actores_habilidades(actor_id,habilidad_id) VALUES($1,$2)',[a.actor_id,x.habilidad_id])}
    for(const e of JSON.parse(b.experiencias||'[]'))await c.query('INSERT INTO experiencias_actor(actor_id,nombre_proyecto,tipo_produccion,rol_desempenado,anio) VALUES($1,$2,$3,$4,$5)',[a.actor_id,e.proyecto,e.tipo,e.rol,e.anio]);
    for(const rd of JSON.parse(b.redes||'[]'))await c.query('INSERT INTO redes_sociales_actor(actor_id,plataforma,url_perfil) VALUES($1,$2,$3)',[a.actor_id,rd.plataforma,rd.url]);
    if(f.video)await c.query("INSERT INTO archivos_multimedia(actor_id,url_archivo,tipo_archivo,titulo) VALUES($1,$2,'VIDEO','Reel')",[a.actor_id,await url(f.video[0])]);
    if(b.acudiente_nombre)await c.query('INSERT INTO acudientes_legales(actor_id,nombre_acudiente,documento_acudiente,telefono_acudiente,correo_acudiente,url_documento_autorizacion,esta_verificado) VALUES($1,$2,$3,$4,$5,$6,false)',
      [a.actor_id,b.acudiente_nombre,b.acudiente_documento,b.acudiente_telefono,b.acudiente_correo,await url(f.autorizacion?.[0])||'PENDIENTE']);
    await c.query("INSERT INTO historial_auditoria(tipo_accion,entidad_afectada,entidad_id,realizado_por_actor_id,observacion_accion) VALUES('CREAR','actores',$1,$1,'Registro público')",[a.actor_id]);
    await c.query('COMMIT');r.json({ok:true})
  }catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}
}));

// Login único: administrador o actor
app.post('/api/login',wrap(async(q,r)=>{
  const {correo,contrasena}=q.body;
  for(const [t,rol,id] of [['administradores','admin','admin_id'],['actores','actor','actor_id']]){
    const {rows:[u]}=await db.query(`SELECT * FROM ${t} WHERE correo=$1 AND esta_activo`,[correo]);
    if(u&&await bcrypt.compare(contrasena,u.contrasena_hash))return r.json({token:jwt.sign({id:u[id],rol},S,{expiresIn:'8h'}),rol,nombre:u.nombre_completo||u.nombre})}
  r.status(401).json({error:'Correo o contraseña incorrectos'})
}));

// RF-07/08 Vitrina pública (solo aprobados) con filtros
const BASE=`SELECT a.actor_id,COALESCE(p.nombre_artistico,a.nombre_completo) nombre,a.ciudad,p.foto_perfil_url foto,date_part('year',age(a.fecha_nacimiento))::int edad,
 COALESCE((SELECT array_agg(h.nombre) FROM actores_habilidades ah JOIN habilidades h USING(habilidad_id) WHERE ah.actor_id=a.actor_id),'{}') habilidades
 FROM actores a JOIN perfiles_actores p USING(actor_id)`;
app.get('/api/actores',wrap(async(q,r)=>{
  const {q:t,ciudad,habilidad,edad_min,edad_max,genero,nivel,est_min,est_max}=q.query,w=["p.estado='APROBADO'"],v=[];
  if(t){v.push('%'+t+'%');w.push(`(a.nombre_completo ILIKE $${v.length} OR p.nombre_artistico ILIKE $${v.length})`)}
  if(ciudad){v.push(ciudad);w.push(`a.ciudad ILIKE $${v.length}`)}
  if(habilidad){v.push(habilidad);w.push(`EXISTS(SELECT 1 FROM actores_habilidades ah JOIN habilidades h USING(habilidad_id) WHERE ah.actor_id=a.actor_id AND h.nombre=$${v.length})`)}
  if(edad_min){v.push(edad_min);w.push(`date_part('year',age(a.fecha_nacimiento))>=$${v.length}`)}
  if(edad_max){v.push(edad_max);w.push(`date_part('year',age(a.fecha_nacimiento))<=$${v.length}`)}
  if(genero){v.push(genero);w.push(`a.genero=$${v.length}`)}if(nivel){v.push(nivel);w.push(`p.nivel_experiencia=$${v.length}`)}
  if(est_min){v.push(est_min);w.push(`a.estatura_cm>=$${v.length}`)}if(est_max){v.push(est_max);w.push(`a.estatura_cm<=$${v.length}`)}
  r.json((await db.query(BASE+' WHERE '+w.join(' AND ')+' ORDER BY nombre',v)).rows)}));
app.get('/api/habilidades',wrap(async(q,r)=>r.json((await db.query('SELECT nombre FROM habilidades ORDER BY nombre')).rows)));
app.get('/api/actores/:id',wrap(async(q,r)=>{
  const {rows:[a]}=await db.query(BASE.replace('p.foto_perfil_url foto','p.foto_perfil_url foto,p.biografia,p.estado,p.reel_url,p.portafolio_url,a.estatura_cm')+' WHERE a.actor_id=$1',[q.params.id]);
  if(!a||a.estado!=='APROBADO')return r.status(404).json({error:'No encontrado'});
  a.experiencias=(await db.query('SELECT * FROM experiencias_actor WHERE actor_id=$1 ORDER BY anio DESC',[a.actor_id])).rows;
  a.redes=(await db.query('SELECT plataforma,url_perfil FROM redes_sociales_actor WHERE actor_id=$1',[a.actor_id])).rows;
  a.video=(await db.query("SELECT url_archivo FROM archivos_multimedia WHERE actor_id=$1 AND tipo_archivo='VIDEO' LIMIT 1",[a.actor_id])).rows[0]?.url_archivo||null;
  r.json(a)}));

// RF-06/16 Panel administrativo
app.get('/api/admin/perfiles',auth('admin'),wrap(async(q,r)=>r.json((await db.query(BASE.replace('p.foto_perfil_url foto','p.foto_perfil_url foto,p.estado,p.biografia,a.correo,a.telefono')+' WHERE p.estado=$1 ORDER BY a.creado_en DESC',[q.query.estado||'PENDIENTE'])).rows)));
app.put('/api/admin/perfiles/:id',auth('admin'),wrap(async(q,r)=>{
  const {estado,motivo}=q.body;if(!['APROBADO','RECHAZADO'].includes(estado))return r.status(400).json({error:'Estado inválido'});
  await db.query('UPDATE perfiles_actores SET estado=$1,motivo_rechazo=$2,revisado_en=now(),revisado_por_admin_id=$3 WHERE actor_id=$4',[estado,motivo||null,q.u.id,q.params.id]);
  await db.query("INSERT INTO historial_auditoria(tipo_accion,entidad_afectada,entidad_id,realizado_por_admin_id,observacion_accion) VALUES('ACTUALIZAR','perfiles_actores',$1,$2,$3)",[q.params.id,q.u.id,estado+(motivo?': '+motivo:'')]);
  r.json({ok:true})}));
// Estado del perfil para el actor autenticado
app.get('/api/mi-perfil',auth('actor'),wrap(async(q,r)=>r.json((await db.query('SELECT estado,motivo_rechazo FROM perfiles_actores WHERE actor_id=$1',[q.u.id])).rows[0])));

require('./fase2')(app,db,auth,wrap);
seedAdmin().then(()=>app.listen(process.env.PORT,()=>console.log('http://localhost:'+process.env.PORT))).catch(e=>{console.error('Error de BD (¿está corriendo Docker?)',e.message);process.exit(1)});
