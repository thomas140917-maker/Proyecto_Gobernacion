CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TYPE tipo_documento_enum AS ENUM ('CC','CE','PASAPORTE','NIT');
CREATE TYPE estado_perfil_enum AS ENUM ('PENDIENTE','APROBADO','RECHAZADO');
CREATE TYPE tipo_accion_auditoria_enum AS ENUM ('CREAR','ACTUALIZAR','ELIMINAR');

CREATE TABLE actores (
 actor_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), correo varchar(201) NOT NULL UNIQUE,
 contrasena_hash varchar(201) NOT NULL, nombre_completo varchar(200) NOT NULL,
 tipo_documento tipo_documento_enum NOT NULL, numero_documento varchar(50) NOT NULL,
 fecha_nacimiento date NOT NULL, municipio varchar(100) NOT NULL, ciudad varchar(100) NOT NULL,
 telefono varchar(20) NOT NULL, genero varchar(20), estatura_cm integer, acepta_terminos boolean NOT NULL, esta_activo boolean NOT NULL,
 creado_en timestamp NOT NULL DEFAULT now());
CREATE TABLE administradores (
 admin_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), correo varchar(201) NOT NULL UNIQUE,
 contrasena_hash varchar(201) NOT NULL, nombre varchar(100) NOT NULL, apellido varchar(100) NOT NULL,
 esta_activo boolean NOT NULL, creado_en timestamp NOT NULL DEFAULT now());
CREATE TABLE perfiles_actores (
 actor_id uuid PRIMARY KEY REFERENCES actores(actor_id) ON DELETE CASCADE,
 nombre_artistico varchar(100), tiene_experiencia boolean NOT NULL, biografia text, foto_perfil_url text, nivel_experiencia varchar(20), reel_url text, portafolio_url text,
 estado estado_perfil_enum NOT NULL, motivo_rechazo text, revisado_en timestamp,
 revisado_por_admin_id uuid REFERENCES administradores(admin_id), actualizado_en timestamp NOT NULL DEFAULT now());
CREATE TABLE acudientes_legales (
 acudiente_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 actor_id uuid NOT NULL REFERENCES actores(actor_id) ON DELETE CASCADE,
 nombre_acudiente varchar(200) NOT NULL, documento_acudiente varchar(50) NOT NULL,
 telefono_acudiente varchar(20) NOT NULL, correo_acudiente varchar(201) NOT NULL,
 url_documento_autorizacion text NOT NULL, esta_verificado boolean NOT NULL,
 verificado_por_admin_id uuid REFERENCES administradores(admin_id));
CREATE TABLE habilidades (
 habilidad_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), nombre varchar(100) NOT NULL UNIQUE,
 tipo varchar(50) NOT NULL DEFAULT 'ESPECIALIDAD', descripcion text);
CREATE TABLE actores_habilidades (
 actor_id uuid NOT NULL REFERENCES actores(actor_id) ON DELETE CASCADE,
 habilidad_id uuid NOT NULL REFERENCES habilidades(habilidad_id) ON DELETE CASCADE,
 descripcion_otra varchar(100), PRIMARY KEY (actor_id, habilidad_id));
CREATE TABLE experiencias_actor (
 experiencia_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 actor_id uuid NOT NULL REFERENCES actores(actor_id) ON DELETE CASCADE,
 nombre_proyecto varchar(100) NOT NULL, tipo_produccion varchar(100) NOT NULL,
 rol_desempenado varchar(100) NOT NULL, anio integer NOT NULL, director_o_productora varchar(100));
CREATE TABLE redes_sociales_actor (
 red_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 actor_id uuid NOT NULL REFERENCES actores(actor_id) ON DELETE CASCADE,
 plataforma varchar(100) NOT NULL, url_perfil text NOT NULL);
CREATE TABLE archivos_multimedia (
 multimedia_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 actor_id uuid NOT NULL REFERENCES actores(actor_id) ON DELETE CASCADE,
 url_archivo text NOT NULL, tipo_archivo varchar(50) NOT NULL, titulo varchar(100),
 subido_en timestamp NOT NULL DEFAULT now());
CREATE TABLE historial_auditoria (
 log_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tipo_accion tipo_accion_auditoria_enum NOT NULL,
 entidad_afectada varchar(100) NOT NULL, entidad_id uuid NOT NULL,
 realizado_por_admin_id uuid REFERENCES administradores(admin_id),
 realizado_por_actor_id uuid REFERENCES actores(actor_id),
 observacion_accion text, creado_en timestamp NOT NULL DEFAULT now());
INSERT INTO habilidades(nombre,tipo) VALUES ('Actuación','AREA'),('Canto','AREA'),('Baile','AREA'),('Doblaje','AREA'),('Teatro','AREA'),('Cine','AREA'),('Modelaje','AREA');

-- ===== FASE 2 =====
CREATE TABLE cursos_y_talleres (
 curso_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), creado_por_admin_id uuid NOT NULL REFERENCES administradores(admin_id),
 titulo varchar(200) NOT NULL, descripcion text, instructor varchar(100),
 fecha_inicio_inscripcion timestamp NOT NULL, fecha_inicio_curso timestamp NOT NULL,
 es_proceso_formacion boolean NOT NULL DEFAULT false, cupo_maximo integer NOT NULL, creado_en timestamp NOT NULL DEFAULT now());
CREATE TABLE noticias (
 noticia_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), creado_por_admin_id uuid NOT NULL REFERENCES administradores(admin_id),
 titulo varchar(200) NOT NULL, resumen_para_carta varchar(200) NOT NULL, resumen_para_galeria text NOT NULL,
 imagen_url text, inicio_descripcion_semestre date, publicado_en timestamp NOT NULL DEFAULT now());
CREATE TABLE convocatorias (
 convocatoria_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), creado_por_admin_id uuid NOT NULL REFERENCES administradores(admin_id),
 titulo varchar(200) NOT NULL, descripcion text NOT NULL, requisitos text, ubicacion varchar(100),
 modalidad varchar(50) NOT NULL, cupo_maximo integer NOT NULL, fecha_cierre timestamp NOT NULL,
 estado estado_perfil_enum NOT NULL, creado_en timestamp NOT NULL DEFAULT now());
CREATE TABLE postulaciones_castings (
 postulacion_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 convocatoria_id uuid NOT NULL REFERENCES convocatorias(convocatoria_id) ON DELETE CASCADE,
 actor_id uuid NOT NULL REFERENCES actores(actor_id) ON DELETE CASCADE,
 estado estado_perfil_enum NOT NULL, postulado_en timestamp NOT NULL DEFAULT now(), UNIQUE(convocatoria_id,actor_id));
INSERT INTO habilidades(nombre,tipo) VALUES ('Televisión','AREA'),('Cortometraje','AREA'),('Publicidad','AREA'),('Drama','ESPECIALIDAD'),('Comedia','ESPECIALIDAD'),('Acción','ESPECIALIDAD'),('Musical','ESPECIALIDAD'),('Infantil','ESPECIALIDAD'),('Histórico','ESPECIALIDAD') ON CONFLICT DO NOTHING;
CREATE TABLE inscripciones_cursos (
 actor_id uuid NOT NULL REFERENCES actores(actor_id) ON DELETE CASCADE,
 curso_id uuid NOT NULL REFERENCES cursos_y_talleres(curso_id) ON DELETE CASCADE,
 progreso integer NOT NULL DEFAULT 0, estado varchar(20) NOT NULL DEFAULT 'EN_PROGRESO', PRIMARY KEY(actor_id,curso_id));
